%%
%   ASD Full Range Spectroradiometer Jump Correction
%   ------------------------------------------------
%   
%   Uses empirical correction coefficients to correct for temperature
%   related radiometric inter-channel steps.
%   For more information please see: 
%       Hueni, A., Bialek, A. and Schaepman, M. E. (2016). 
%       "Cause, Effect and Correction of ASD Spectroradiometer Inter-channel Radiometric Steps." 
%       IEEE Trans. on Geoscience and Remote Sensing, submitted.
%
%   Please cite the above paper if you use this method in any published work.
%	
%   Input Parameters
%   ----------------
%   coeffs : correction coefficients supplied with this function (2nd order polynomial coefficients)
%
%   spectrum : spectrum to be corrected as a vector (2151 bands)
%
%   wvl : wavelength vector (350 nm : 2500 nm)
%
%   iteration : used to control the iteration; set to zero upon call or leave empty []
%
%   jump_size_matrix : used in the iteration to collect jump size convergence data; leave empty [] upon call
%
%   Output Parameters
%   ----------------
%
%   corrected_spectrum : spectrum after correction
%
%   outside_T : estimated ambient temperature (currently biased due to
%   unresolved at-sensor radiance dependencies)
%
%   spec_corr_factors : applied correction factors (final factors after
%   all iterations)
%
%   jump_size_matrix : Matrix holding the jump sizes for VNIR-SWIR1 and
%   SWIR1-SWIR2 for all iterations
%
%
%   Example
%   --------
%           load('asd_temp_corr_coeffs.mat')
%           [corrected_spectrum, T_estimate, spec_corr_factors, jump_size_matrix] = asd_jump_correction(asd_temp_corr_coeffs, spectrum_to_correct, wvl, [], []);
%
%   -------------------------------------------
%   (c) 2016 A.Hueni, RSL, University of Zurich
%   -------------------------------------------
%%

function [corrected_spectrum, outside_T, spec_corr_factors, jump_size_matrix] = ASD_Jump_Correction(coeffs, spectrum, wvl, iteration, jump_size_matrix)

    if isempty(iteration)
        iteration = 0;
    end

    if isempty(jump_size_matrix)
        jump_size_matrix = []; % used to document the convergence
    end

    % use linear extrapolation to estimate the values in the last VNIR band and
    % first SWIR2 band
    [m, i] = get_closest_wvl_index(wvl, 1001);
    p = polyfit(1001:1003, spectrum(i:i+2), 1);
    last_vnir_estimate = polyval(p, 1000);
    
    last_vnir_ind = i-1;
    first_swir = spectrum(i);
    last_vnir = spectrum(last_vnir_ind);
    jump_size_matrix(1,end+1) = first_swir - last_vnir;

    corr_factor_last_vnir = last_vnir_estimate / last_vnir;
    
    [m, first_swir2_ind] = get_closest_wvl_index(wvl, 1801);
    last_swir1_ind = first_swir2_ind-1;
    p = polyfit(1798:1800, spectrum(last_swir1_ind-2:last_swir1_ind), 1);
    first_swir2_estimate = polyval(p, 1801);
    
    if 1==0    
        % documentation
        figure
        plot(1798:1800, spectrum(last_swir1_ind-2:last_swir1_ind))
        hold
        plot(1801, first_swir2_estimate, 'o')                
    end

    
    first_swir2 = spectrum(first_swir2_ind);
    last_swir1 = spectrum(last_swir1_ind);
    jump_size_matrix(2,end) = last_swir1 - first_swir2;

    corr_factor_first_swir2 = first_swir2_estimate / first_swir2;
    
    % goal: identify an outside temperature where the correction gains
    % established above are met
    % ax2 + bx + c = 0
    
    
    [T_vnir, Ts_vnir] = rqe(coeffs(last_vnir_ind, 1),coeffs(last_vnir_ind, 2),coeffs(last_vnir_ind, 3)-corr_factor_last_vnir);
    [T_swir, Ts_swir] = rqe(coeffs(first_swir2_ind, 1),coeffs(first_swir2_ind, 2),coeffs(first_swir2_ind, 3)-corr_factor_first_swir2);
    
    outside_T = mean([T_vnir T_swir]);
    
    % get transformation factors using these temperatures and correct the
    % spectrum.   
    [m, splice_band] = get_closest_wvl_index(wvl, 1726);
    T_vector = zeros(size(wvl));
    T_vector(1:splice_band) = T_vnir;
    T_vector(splice_band+1:end) = T_swir;
    
    spec_corr_factors = coeffs(:,1).*T_vector.^2 + coeffs(:,2).*T_vector + coeffs(:,3);
    
    if 1 ==0
        % documentation
        figure
        plot(wvl, spec_corr_factors)
    end
    
    corrected_spectrum = spectrum .* spec_corr_factors';

    % iterative call
    if iteration < 3
        [corrected_spectrum_iterated, ~, ~, jump_size_matrix] = ASD_Jump_Correction(coeffs, corrected_spectrum, wvl, iteration+1, jump_size_matrix);

        if (1==0)
            % documentation
            figure
            hold
            plot(wvl, spectrum, 'k');
            plot(wvl, corrected_spectrum)
            plot(wvl, corrected_spectrum_iterated, 'r')
        end   
        
        corrected_spectrum = corrected_spectrum_iterated;
        
        % recalculate the temperatures based on iterated correction
        % coefficients
        
        spec_corr_factors_recalc = corrected_spectrum ./ spectrum;
        spec_corr_factors = spec_corr_factors_recalc;
        
        [T_vnir, Ts_vnir] = rqe(coeffs(last_vnir_ind, 1),coeffs(last_vnir_ind, 2),coeffs(last_vnir_ind, 3)-spec_corr_factors_recalc(last_vnir_ind));
        [T_swir, Ts_swir] = rqe(coeffs(first_swir2_ind, 1),coeffs(first_swir2_ind, 2),coeffs(first_swir2_ind, 3)-spec_corr_factors_recalc(first_swir2_ind));

        outside_T = mean([T_vnir T_swir]);     

    else
        
        if 1 == 0
            % documentation
            FontSize = 12;
            TitleFontSize = 16;
            linewidth = 1.5;    

            fh=figure;
            [AX,f1,f2] = plotyy(1:size(jump_size_matrix,2), jump_size_matrix(1,:), 1:size(jump_size_matrix,2), jump_size_matrix(2,:));

            set(f1, 'LineWidth',linewidth)
            set(f2, 'LineWidth',linewidth)

            legend({'VNIR Jump Size', 'SWIR2 Jump Size'}, 'Location', 'NorthEast');
            title_str = 'Convergence of Jump Sizes';
            title(title_str, 'FontSize', TitleFontSize);

            set(get(AX(1),'Ylabel'),'String','Radiance (L_\lambda) [W/m2/sr/nm]', 'FontSize', FontSize)
            set(get(AX(2),'Ylabel'),'String','Radiance (L_\lambda) [W/m2/sr/nm]', 'FontSize', FontSize)


            set(get(AX(1),'Xlabel'),'String','Iteration Step', 'FontSize', FontSize)
            set(get(AX(1),'Xlabel'),'String','Iteration Step', 'FontSize', FontSize)

            print_pdf(fh, '/Users/andyhueni/Data/Studies/RSL/Instruments/ASD/Temperature Experiment at NPL - Results/', title_str);

        end
        
            
    end

end


% Predict the temperature by finding the roots of the second order polynomial
% The two solutions are checked for a feasible
% range to return a single assumed outside temperature
function [T, Ts] = rqe(a,b,c)
    Ts(1) = (-b + sqrt(b^2 - 4 * a * c))/(2*a);
    Ts(2) = (-b - sqrt(b^2 - 4 * a * c))/(2*a);

    % temperature range: -10C - 50C
    T_feasible_ind = Ts > -10 & Ts < 50;
    
    T = Ts(T_feasible_ind);
    
end
